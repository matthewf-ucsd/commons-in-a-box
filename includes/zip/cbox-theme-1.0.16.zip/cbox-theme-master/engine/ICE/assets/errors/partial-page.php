<?php
	print str_replace( '&lt/script&gt', '</script>', $_POST['html'] );
?>